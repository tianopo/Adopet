
import { Click } from "./models/click.js";

const caixa = document.querySelectorAll('.nome--cao');
const balaozao = document.querySelectorAll('.balaozao');

Click.cliqueHome(caixa,'mensagem.html');
Click.cliqueHome(balaozao,'mensagem.html');
